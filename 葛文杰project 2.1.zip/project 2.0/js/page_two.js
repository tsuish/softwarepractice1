window.onload = function(){
	//将获取到的院校名称和代码插入到标题中
	set_uni_name_and_uni_code();
	//绑定目录的鼠标悬浮事件和鼠标点击事件
	bind_catalog_onmouseover_and_onclick();
	//刚跳转过来时显示招生简章页面
	get_content_for_recruit();

};

///////////////////////其他函数//////////////////////////
//通过发送请求获取分数线信息将其展示到content中
function get_content_for_score(){
	var content = get_content();
	var uni_name = get_uni_name().innerText;
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderScoList?sco_uni_name="+uni_name;

	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;

			//全局变量
		    var obj = eval ("(" + txt + ")");
		    var inner = '<table class="table table-dark table-hover text-center">'+
    			'<thead>'+
      				'<tr>'+
        				'<th>年份</th>'+
        				'<th>院系</th>'+
        				'<th>专业</th>'+
        				'<th>国家线</th>'+
        				'<th>复试分数线</th>'+
        				'<th>自主线</th>'+
        				'<th>政治</th>'+
        				'<th>外语</th>'+
        				'<th>业务一</th>'+
        				'<th>业务二</th>'+
      				'</tr>'+
    			'</thead>'+
    			'<tbody>';
		    for (var i = 0; i < obj.length; i++) {
		    	inner += '<tr>'+
    					'<td>'+obj[i].sco_year+'</td>'+
        				'<td>'+obj[i].sco_college_name+'</td>'+
        				'<td>'+obj[i].sco_maj_name+'</td>'+
        				'<td>'+obj[i].sco_country_line+'</td>'+
        				'<td>'+obj[i].sco_reexamine_line+'</td>'+
        				'<td>'+obj[i].sco_self_line+'</td>'+
        				'<td>'+obj[i].sco_subject1+'</td>'+
        				'<td>'+obj[i].sco_subject2+'</td>'+
        				'<td>'+obj[i].sco_subject3+'</td>'+
        				'<td>'+obj[i].sco_subject4+'</td>'+
    				'</tr>';
		    }
		     inner += 
		     			'</tbody>'+
					'</table>';
		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//通过发送请求获取报录信息将其展示到content中
function get_content_for_enrol(){
	var content = get_content();
	var uni_name = get_uni_name().innerText;
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderREList?res_uni_name="+uni_name;

	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;

			//全局变量
		    var obj = eval ("(" + txt + ")");
		    var inner = '<table class="table table-dark table-hover text-center">'+
    			'<thead>'+
      				'<tr>'+
        				'<th>年份</th>'+
        				'<th>院系</th>'+
        				'<th>专业</th>'+
        				'<th>研究方向</th>'+
        				'<th>报考人数</th>'+
        				'<th>录取人数</th>'+
      				'</tr>'+
    			'</thead>'+
    			'<tbody>';
		    for (var i = 0; i < obj.length; i++) {
		    	inner += '<tr>'+
    					'<td>'+obj[i].res_year+'</td>'+
        				'<td>'+obj[i].res_college_name+'</td>'+
        				'<td>'+obj[i].res_maj_name+'</td>'+
        				'<td>'+obj[i].res_name+'</td>'+
        				'<td>'+obj[i].res_register_num+'</td>'+
        				'<td>'+obj[i].res_enroll_num+'</td>'+
    				'</tr>';
		    }
		     inner += 
		     			'</tbody>'+
					'</table>';
		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//通过发送请求获取专业目录将其展示到content中
function get_content_for_major(){
	var content = get_content();
	var uni_name = document.getElementById("uni_name").innerText;
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderMajListbyUniname?maj_uni_name="+uni_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;

			//全局变量
		    var obj = eval ("(" + txt + ")");
		    var inner = '<table class="table table-dark table-hover text-center">'+
    			'<thead>'+
      				'<tr>'+
        				'<th>年份</th>'+
        				'<th>院系</th>'+
        				'<th>专业</th>'+
        				'<th>专业代码</th>'+
        				'<th>研究方向</th>'+
        				'<th>考试范围</th>'+
        				'<th>跨专业</th>'+
        				'<th>学制</th>'+
        				'<th>学术类型</th>'+
      				'</tr>'+
    			'</thead>'+
    			'<tbody>';
      				
		    for (var i = 0; i < obj.length; i++) {
		    	inner += '<tr>'+
      					'<td>'+obj[i].maj_year+'</td>'+
        				'<td>'+obj[i].maj_college_name+'</td>'+
        				'<td>'+obj[i].maj_name+'</td>'+
        				'<td>'+obj[i].maj_code+'</td>'+
        				'<td><a href="#" name="research_direction">详细</a></td>'+
        				'<td><a href="#" name="exam_scope">详细</a></td>';
        				if(obj[i].maj_transdisciplinary == "true"){
        					inner += '<td>支持</td>';
        				}else {
        					inner += '<td>不支持</td>';
        				}
        				inner += 
        						'<td>'+obj[i].maj_system+'</td>'+
        						'<td>'+obj[i].maj_acdemic+'</td>'+
      							'</tr>';
		    }
		     inner += 
		     			'</tbody>'+
					'</table>';
		    content.innerHTML = inner;
		    //给a标签绑定事件
		    bind_for_research_direction();
		    bind_for_exam_scope();

		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}

//通过发送URL获取招生简章的内容并将其插入到content中。
function get_content_for_recruit(){
	var content = get_content();
	var uni_name = document.getElementById("uni_name").innerText;
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderRecListbyUniname?rec_uni_name="+uni_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;

			//全局变量
		    var obj = eval ("(" + txt + ")");
		    var inner = '<div class="text_white_zsjz">'+obj[0].rec_year+'年招生简章:</div>'+
				'<div class="text_white">'+obj[0].rec_content+'</div>';

		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//删除content中的所有内容
function del_content(){
	var content = document.getElementById("content");
	content_children = content.children;
	for (var i = content_children.length - 1; i >=0; i--) {
		content.removeChild(content_children[i]);
	}
}

//将获取到的院校名称和院校代码插入到标题中
function set_uni_name_and_uni_code(){
	
	var name = document.getElementById("uni_name");
	var code = document.getElementById("uni_code");

	name.innerText = decodeURI(get_parameter_uni_name());
	code.innerText = get_parameter_uni_code();

	name.style.fontSize = "30px";
	code.style.fontSize = "30px";

}

//获取URL上的院校名称
function get_parameter_uni_name(){
	var parameters = location.search;
  	if ( parameters.indexOf( "?" ) != -1 ) {
    	var parameter = parameters.substr( 1 ); //substr()方法返回从参数值开始到结束的字符串；
    	var strs = parameter.split( "&");
    	var str = strs[0];
    	var uni_name = str.split("=")[1];
    	return uni_name;
  	}
}

//获取URL上的院校代码
function get_parameter_uni_code(){
	var parameters = location.search;
  	if ( parameters.indexOf( "?" ) != -1 ) {
    	var parameter = parameters.substr( 1 ); //substr()方法返回从参数值开始到结束的字符串；
    	var strs = parameter.split( "&");
    	var str = strs[1];
    	var uni_code = str.split("=")[1];
    	return uni_code;
  	}
}
////////////////////事件绑定函数////////////////////////
//给考试范围a标签绑定点击事件
function bind_for_exam_scope(){
	var exam_scope = get_exam_scope();	
	for (var i = 0; i < exam_scope.length; i++) {
		exam_scope[i].onclick = exam_scope_detailed;
	}
}
//给研究方向a标签绑定点击事件
function bind_for_research_direction(){
	var research_directions = get_research_direction();
	for (var i = 0; i < research_directions.length; i++) {
		research_directions[i].onclick = research_direction_detailed;
	}
	// console.log(research_directions[0].innerText);
}




//绑定目录的鼠标悬浮事件和鼠标点击事件
function bind_catalog_onmouseover_and_onclick(){
	var recruit = get_catalog_recruit();
	var major = get_catalog_major();
	var score = get_catalog_score();
	var enrol = get_catalog_enrol();
	catalogs = get_catalogs();

	recruit.onmouseover = onmouseover_for_catalog;
	major.onmouseover = onmouseover_for_catalog;
	score.onmouseover = onmouseover_for_catalog;
	enrol.onmouseover = onmouseover_for_catalog;

	recruit.onmouseout = onmouseout_for_catalog;
	major.onmouseout = onmouseout_for_catalog;
	score.onmouseout = onmouseout_for_catalog;
	enrol.onmouseout = onmouseout_for_catalog;	

	recruit.onclick = onclick_for_catalog;
	major.onclick = onclick_for_catalog;
	score.onclick = onclick_for_catalog;
	enrol.onclick = onclick_for_catalog;
}
///////////////////////事件函数////////////////////////


//研究方向a标签点击事件
function research_direction_detailed(){
	del_content();
	var uni_name = get_uni_name().innerText;
	var maj_college_name = get_maj_college_name().innerText;
	var maj_name = get_maj_name().innerText;


	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderRDList?res_uni_name="+uni_name+"&res_college_name="+maj_college_name+"&res_maj_name="+maj_name;
	console.log(URL);
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){


			var txt = xmlhttp.responseText;
			var inner = '<table class="table table-dark table-hover text-center">'+
    			'<thead>'+
      				'<tr>'+
        				'<th>年份</th>'+
        				'<th>方向名称</th>'+
        				'<th>所属专业</th>'+
        				'<th>学习方式</th>'+
        				'<th>指导教师</th>'+
      				'</tr>'+
    			'</thead>'+
    			'<tbody>';
		    var obj = eval ("(" + txt + ")");
		   	for (var i = 0; i < obj.length; i++) {
		   		inner += '<tr>'+
    					'<td>'+obj[i].res_year+'</td>'+
    					'<td>'+obj[i].res_name+'</td>'+
    					'<td>'+obj[i].res_maj_name+'</td>'+
    					'<td>'+obj[i].res_way+'</td>'+
    					'<td><a href="#">详情</a></td>'+
    				'</tr>';
		   	}
		   	inner += 	'</tbody>'+
    				  '</table>';
		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();	
}
//考试范围a标签点击事件
function exam_scope_detailed(){
	del_content();
	var uni_name = get_uni_name().innerText;
	var college_name = get_maj_college_name().innerText;
	var maj_name = get_maj_name().innerText;


	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderExaList?exa_uni_name="+uni_name+"&exa_college_name="+college_name+"&exa_maj_name="+maj_name;
	console.log(URL);
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){


			var txt = xmlhttp.responseText;
			var inner = '<div>';

		    var obj = eval ("(" + txt + ")");
		   	for (var i = 0; i < obj.length; i++) {
		   		if(obj[i].exa_subject2 != "" && obj[i].exa_subject2 != null){
		   			inner +='<h2 class="text_white">年份：'+obj[i].exa_year+'</h2>'+
					'<p class="text_white">业务课一：'+obj[i].exa_subject1+'</p>'+
					'<p class="text_white">业务课二：'+obj[i].exa_subject2+'</p>'+
					'<p class="text_white">业务课三：'+obj[i].exa_subject3+'</p>'+
					'<p class="text_white">业务课四：'+obj[i].exa_subject4+'</p>';
		   		}else {
		   			inner +='<h2 class="text_white">年份：'+obj[i].exa_year+'</h2>'+
					'<p class="text_white">考试范围：'+obj[i].exa_subject1+'</p>';
		   		}
		   	}
		   	inner += '</div>';
		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//目录的鼠标悬浮事件
function onmouseover_for_catalog(){
	var recruit = get_catalog_recruit();
	var major = get_catalog_major();
	var score = get_catalog_score();
	var enrol = get_catalog_enrol();
	if(recruit.style.backgroundColor == "white"){
		recruit.style.backgroundColor = "#555";
	}else if(major.style.backgroundColor == "white"){
		major.style.backgroundColor = "#555";
	}else if(score.style.backgroundColor == "white"){
		score.style.backgroundColor = "#555";
	}else if(enrol.style.backgroundColor == "white"){
		 enrol.style.backgroundColor = "#555";
	}

	if(event.target.innerText == "招生简章"){
		recruit.style.backgroundColor = "white";
		recruit.style.cursor = 'pointer';
	}else if(event.target.innerText == "专业目录"){
		 major.style.backgroundColor = "white";
		 major.style.cursor = 'pointer';
	}else if(event.target.innerText == "分数线"){
		score.style.backgroundColor = "white";
		score.style.cursor = 'pointer';
	}else if(event.target.innerText == "报录信息"){
		enrol.style.backgroundColor = "white";	
		enrol.style.cursor = 'pointer';
	}
}
//鼠标悬浮离开事件
function onmouseout_for_catalog(){
	var recruit = get_catalog_recruit();
	var major = get_catalog_major();
	var score = get_catalog_score();
	var enrol = get_catalog_enrol();
	if(recruit.style.backgroundColor == "white"){
		recruit.style.backgroundColor = "#555";
	}else if(major.style.backgroundColor == "white"){
		major.style.backgroundColor = "#555";
	}else if(score.style.backgroundColor == "white"){
		score.style.backgroundColor = "#555";
	}else if(enrol.style.backgroundColor == "white"){
		 enrol.style.backgroundColor = "#555";
	}
}
//目录的鼠标点击事件
function onclick_for_catalog(){
	//先删除content中的内容，再向其中插入内容
	del_content();
	if(event.target.innerText == "招生简章"){
		get_content_for_recruit();
	}else if(event.target.innerText == "专业目录"){
		get_content_for_major();
	}else if(event.target.innerText == "分数线"){
		get_content_for_score();
	}else if(event.target.innerText == "报录信息"){
		get_content_for_enrol();
	}
}



////////////////////////获取html节点/////////////////////////
function get_catalogs(){
	var catalog = document.getElementById("catalog");
	return catalog.children;
}

function get_catalog_recruit(){
	return document.getElementById("recruit");
}
function get_catalog_major(){
	return document.getElementById("major");
}
function get_catalog_score(){
	return document.getElementById("score");
}
function get_catalog_enrol(){
	return document.getElementById("enrol");
}
function get_content(){
	return document.getElementById("content");
}
function get_research_direction(){
	return document.getElementsByName("research_direction");
}
function get_exam_scope(){
	return document.getElementsByName("exam_scope");	
}
function get_maj_college_name(){
	if(event.srcElement.tagName == "A"){
		var tr = event.srcElement.parentNode.parentNode;
		var tds = tr.children;
		return tds[1];
	}
}
function get_maj_name(){
	if(event.srcElement.tagName == "A"){
		var tr = event.srcElement.parentNode.parentNode;
		var tds = tr.children;
		return tds[2];
	}
}
function get_uni_name(){
	return document.getElementById("uni_name");
}
////////////////////调用别人的函数///////////////////////////



























