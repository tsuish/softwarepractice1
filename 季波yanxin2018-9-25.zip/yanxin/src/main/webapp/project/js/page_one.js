//入口函数
$(function(){
	//地区选择的鼠标悬浮事件绑定
	bind_region_onmouseover();
	//地区选择的鼠标点击事件
	bind_region_onclick();
	//翻页事件的绑定
	bind_through_the_pages()
	//院校特性鼠标点击事件绑定
	bind_characteristic_of_universities()
	//搜索鼠标点击时间绑定
	bind_search();
	//加载全部数据
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderUniListbyFiltrate?city=";
	send_request(URL);
	//绑定搜索框的回车事件
	bind_search_enter();
});

///////////////////////其他函数////////////////////////////////
//获取地区选择的所有span
function getAll_span_region(){
	var span_region = document.getElementById("d_0");
	var region_selection = span_region.parentNode;
	var span_regions = region_selection.children;
	return span_regions;
}
//检查地区选择中背景颜色是否有黑色，如果有，将背景颜色变白，字体变黑
function check_background_color_black(){
	var span_regions = getAll_span_region();
	for (var i = 0; i < span_regions.length; i++) {
		if(span_regions[i].tagName == "SPAN" && span_regions[i].style.backgroundColor=="rgb(0, 0, 0)"){
				span_regions[i].style.backgroundColor = 'white';
				span_regions[i].style.color = '#000000';	
		}
	}
}
function send_request(URL){
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{

			var txt = xmlhttp.responseText;
			//全局变量
		    obj = eval ("(" + txt + ")");
		    var tbody = document.getElementById("tbody");
			var trs = tbody.children;
			//删除trs
			del_trs();
			//要插入的数据
			var inner="";
			// 极限页码数设置为全局变量
		    page_limit_num = 0;
			if(obj.length % 20 != 0 ){
				page_limit_num  = parseInt(obj.length / 20)+1;
			}else {
				page_limit_num  = obj.length / 20;
			}
			if(obj.length <=0){
				//要插入的内容
				inner = '<b>对不起，没有查询到您所需要信息</b>';
      			
      			tbody.innerHTML = inner;

			}else if(obj.length<=20 && obj.length>0){
		    	for (var i = 0; i < obj.length; i++) {

		    		 	inner += '<tr>'+
        				'<td><a href="page_two.html?uni_name='+obj[i].uni_name+'&uni_code='+obj[i].uni_code+'" target="_blank">'+"("+obj[i].uni_code+")"+obj[i].uni_name+'</a></td>'+
        				'<td>'+obj[i].uni_location+'</td>'+
        				'<td>'+obj[i].uni_subjection+'</td>'+
        				'<td>'+obj[i].uni_characteristic+'</td>';
        				if(obj[i].uni_graduate_school){
							inner+='<td>有</td>';
						}else {
							inner+='<td>没有</td>';
						}
						if(obj[i].uni_self_line){
							inner+='<td>是</td>';	
						}else {
							inner+='<td>否</td>'+
							'</tr>';
						}
		    	}

		    	tbody.innerHTML = inner;
		    }else if(obj.length>20){
		    	
		    	insert_trs(0,20,obj);
		    	
		    }
		    var page_num = document.getElementById("page_num");
			page_num.innerText = 1;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//地区选择点击事件之后使用ajax向后台发送URL请求
function onclick_span_region_send_request(city){
	if(city == "全部"){
		city = "";
	}
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderUniListbyFiltrate?city="+city;
	send_request(URL);
}

//起始数，终止数，数组
function insert_trs(start,end,obj){
	var inner="";
	var tbody = document.getElementById("tbody");
	for (var i = start; i < end; i++) {
		inner += '<tr>'+
        '<td><a href="page_two.html?uni_name='+obj[i].uni_name+'&uni_code='+obj[i].uni_code+'" target="_blank">'+"("+obj[i].uni_code+")"+obj[i].uni_name+'</a></td>'+
        '<td>'+obj[i].uni_location+'</td>'+
        '<td>'+obj[i].uni_subjection+'</td>'+
        '<td>'+obj[i].uni_characteristic+'</td>';
        if(obj[i].uni_graduate_school){
			inner+='<td>有</td>';
		}else {
			inner+='<td>没有</td>';
		}
		if(obj[i].uni_self_line){
			inner+='<td>是</td>';	
		}else {
			inner+='<td>否</td>'+
			'</tr>';
		}
	}

	// 插入
	tbody.innerHTML = inner;
}


//删除trs
function del_trs(){
	var tbody = document.getElementById("tbody");
	var trs = tbody.children;
	//当循环删除字节点时，应当从后往前循环删除
	for(var i=trs.length-1; i>=0; i--){
		tbody.removeChild(trs[i]);
	}

}

//院校特性鼠标点击事件之后，向后台发送请求
function onclick_send_request(city,is_985,is_211,is_graduate_school,is_self_line){
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderUniListbyFiltrate?city="+city;
	if(is_985){
		URL += "&is_985=true";
	}
	if(is_211){
		URL+= "&is_211=true";
	}
	if(is_graduate_school){
		URL+= "&is_graduate_school=true";
	}
	if(is_self_line){
		URL+= "&is_self_line=true";
	}
	
	send_request(URL);
}
function get_parameter_and_onclick_send_request(){
	var div = document.getElementById("characteristic");
	var inputs = div.children;

	var is_985 = inputs[0].checked;
	var is_211 = inputs[1].checked;
	var is_graduate_school = inputs[2].checked;
	var is_self_line = inputs[3].checked;
	var span_regions = getAll_span_region();
	var city = "";
	
	for (var i = 0; i < span_regions.length; i++) {
		if(span_regions[i].style.backgroundColor == "rgb(0, 0, 0)"){
			city = span_regions[i].innerText;
		}
	}
	if(city == "全部"){
		city = "";
	}
	onclick_send_request(city,is_985,is_211,is_graduate_school,is_self_line);
}
/////////////////绑定事件函数////////////////////////////
//搜索框回车事件绑定
//这里绑定是全局的搜素框事件
function bind_search_enter(){
	var search_input = document.getElementById("search_input");
	search_input.onkeydown = function(){
		
	};
	search_input.onkeyup = function(){
		if (event.keyCode == 13) {
			onclick_search();
		}
	}
}
//搜索框点击事件绑定
function bind_search(){
	var search = document.getElementById("search");
	search.onclick = onclick_search;
}
//搜索框点击事件
function onclick_search(){
	var search = document.getElementById("search");
	var keywords = search.parentNode.children[0].value;
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderUniListbySearch?keywords="+keywords;
	send_request(URL);
}
//院校特性鼠标点击事件绑定
function bind_characteristic_of_universities(){
	var div = document.getElementById("characteristic");
	var inputs = div.children;
	for (var i = 0; i < inputs.length; i++) {
		inputs[i].onclick = characteristic_of_universities;
	}
}
//地区选择的鼠标点击事件绑定
function bind_region_onclick(){
	var span_regions = getAll_span_region();
	span_regions[0].style.backgroundColor = '#000000';
	span_regions[0].style.color = 'white';
	for (var i = 0; i < span_regions.length; i++) {
		if(span_regions[i].tagName == "SPAN"){
			span_regions[i].onclick = region_onclick;
		}
	} 
}
//地区选择的鼠标悬浮事件绑定
function bind_region_onmouseover(){
	var span_regions = getAll_span_region();
	for (var i = 0; i < span_regions.length; i++) {
		if(span_regions[i].tagName == "SPAN"){
			span_regions[i].onmouseover = region_onmouseover;
		}
	}
}

//翻页事件的绑定
function bind_through_the_pages(){
	var first_page = document.getElementById("first_page");
	var previous_page = document.getElementById("previous_page");
	var next_page = document.getElementById("next_page");
	var last_page = document.getElementById("last_page");


	//悬浮事件的绑定
	first_page.onmouseover = through_the_pages_onmouseover;
	previous_page.onmouseover = through_the_pages_onmouseover;
	next_page.onmouseover = through_the_pages_onmouseover;
	last_page.onmouseover = through_the_pages_onmouseover;

	//点击事件的绑定
	first_page.onclick = through_the_pages_first_page;
	previous_page.onclick = through_the_pages_previous_page;
	next_page.onclick = through_the_pages_next_page;
	last_page.onclick = through_the_pages_last_page;


}

//////////////////////事件函数////////////////////////////

//院校特性鼠标点击事件
function characteristic_of_universities(){
	get_parameter_and_onclick_send_request();

}
//地权选择鼠标点击事件
function region_onclick(){
	if(event.srcElement && event.srcElement.tagName=="SPAN"){
		var span_region = event.srcElement;
		check_background_color_black();
		span_region.style.backgroundColor = '#000000';
		span_region.style.color = 'white';
		get_parameter_and_onclick_send_request();
	}
}

//地区选择鼠标悬浮事件
function region_onmouseover(){
	if(event.srcElement && event.srcElement.tagName=="SPAN"){
		var span_region = event.srcElement;
		span_region.style.cursor ='pointer';
	}
}

//翻页鼠标悬浮事件
function through_the_pages_onmouseover(){
	if(event.srcElement && event.srcElement.tagName=="SPAN"){
		var through_the_pages = event.srcElement;
		through_the_pages.style.cursor ='pointer';
	}
}

// 首页点击事件
function through_the_pages_first_page(){
	//使用全局变量obj
	insert_trs(0,20,obj);
	//重置页码为1
	var page_num = document.getElementById("page_num");
	page_num.innerText = 1;
}
//下一页点击事件
function through_the_pages_next_page(){
	var page_num = document.getElementById("page_num");
	//获取当前页码数
	var page_number = parseInt(page_num.innerText);
	
	if(page_number+1 < page_limit_num){
		//清除原来的tbody
		del_trs();
		insert_trs(page_number*20,(page_number+1)*20,obj);	
		//更新页码数
		page_num.innerText = page_number+1;
	}else if(page_number+1 == page_limit_num){

		del_trs();
		insert_trs(page_number*20,obj.length,obj);
		//更新页码数
		page_num.innerText = page_number+1;
	}else {
		showTips("已经是最后一页",700,1);
	}

} 
// 上一页点击事件
function through_the_pages_previous_page(){
	var page_num = document.getElementById("page_num");
	//获取当前页码数
	var page_number = parseInt(page_num.innerText);
	if(page_number-1 > 1){
		//清除原来的tbody
		del_trs();
		insert_trs((page_number-2)*20,(page_number-1)*20,obj);	
		//更新页码数
		page_num.innerText = page_number-1;
	}else if(page_number-1 == 1){

		del_trs();
		insert_trs((page_number-2)*20,(page_number-1)*20,obj);
		//更新页码数
		page_num.innerText = page_number-1;
	}else {
		showTips("已经是第一页",700,1);
	}
}
//末页点击事件
function through_the_pages_last_page(){
	/*
		判断obj的长度
			小于等于20
				显示0到obj.length
				并提示当前已经是最后一页
			大于20
				（根据极限页码数-1）* 20 -- obj.length;
	*/ 
	if(obj.length <=20){
		insert_trs(0,obj.length,obj);
	}else if(obj.length >20){
		insert_trs((page_limit_num-1)*20,obj.length,obj);
	}
	var page_num = document.getElementById("page_num");
	page_num.innerText = page_limit_num;
}

///////////////////////////////////调用别人的函数/////////////////////////////////////////////
/*
  显示信息提示后自动关闭
  参数说明:
  content:要显示的内容
  height:距离窗口顶部的距离
  time:为多少秒之后关闭
*/
function showTips( content, height, time ){
	//窗口的宽度
  var windowWidth  = $(window).width();
  var tipsDiv = '<div class="tipsClass">' + content + '</div>';
 
  $( 'body' ).append( tipsDiv );
  $( 'div.tipsClass' ).css({
      'top'       : height + 'px',
      'left'      : ( windowWidth / 2 ) - 350/2 + 'px',
      'position'  : 'absolute',
      'padding'   : '3px 5px',
      'background': '#8FBC8F',
      'font-size' : 20 + 'px',
      'margin'    : '0 auto',
      'text-align': 'center',
      'width'     : '350px',
      'height'    : 'auto',
      'color'     : '#fff',
      'opacity'   : '0.8'
  }).show();
  setTimeout( function(){$( 'div.tipsClass' ).fadeOut();}, ( time * 1000 ) );
}