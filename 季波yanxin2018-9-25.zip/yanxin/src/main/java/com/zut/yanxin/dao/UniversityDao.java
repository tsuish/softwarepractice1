package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.University;

public interface UniversityDao {
	//获取所有院校信息
	public List<University> getAll();
	//根据搜索框查找信息
	public List<University> getAllbySearch(String keywords);
	//根据条件筛选信息
	public List<University> getAllbyFiltrate(String city,String is_211,String is_985,String is_graduate_school,String is_self_line);
}
