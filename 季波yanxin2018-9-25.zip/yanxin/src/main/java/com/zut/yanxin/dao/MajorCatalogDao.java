package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.MajorCatalog;

public interface MajorCatalogDao {
//根据院校名称获取所有专业信息
	public List<MajorCatalog> getInfo(String maj_uni_name);
}
