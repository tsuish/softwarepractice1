package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.ResearchDirection;

public interface ResearchDirectionDao {
	//根据院校、学院、专业查研究方向的信息
	public List<ResearchDirection> getRDInfo(String res_uni_name,String res_college_name,String res_maj_name);
	//根据院校名查询报录信息
	public List<ResearchDirection> getREInfo(String res_uni_name);
}
