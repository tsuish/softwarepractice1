package com.zut.yanxin.entity;

public class ExamArea {
private int exa_id;
private String exa_year;
private String exa_maj_name;
private String exa_college_name;
private String exa_uni_name;
private String exa_subject1;
private String exa_subject2;
private String exa_subject3;
private String exa_subject4;
public ExamArea(int exa_id, String exa_year, String exa_maj_name, String exa_college_name, String exa_uni_name,
		String exa_subject1, String exa_subject2, String exa_subject3, String exa_subject4) {
	super();
	this.exa_id = exa_id;
	this.exa_year = exa_year;
	this.exa_maj_name = exa_maj_name;
	this.exa_college_name = exa_college_name;
	this.exa_uni_name = exa_uni_name;
	this.exa_subject1 = exa_subject1;
	this.exa_subject2 = exa_subject2;
	this.exa_subject3 = exa_subject3;
	this.exa_subject4 = exa_subject4;
}
public int getExa_id() {
	return exa_id;
}
public void setExa_id(int exa_id) {
	this.exa_id = exa_id;
}
public String getExa_year() {
	return exa_year;
}
public void setExa_year(String exa_year) {
	this.exa_year = exa_year;
}
public String getExa_maj_name() {
	return exa_maj_name;
}
public void setExa_maj_name(String exa_maj_name) {
	this.exa_maj_name = exa_maj_name;
}
public String getExa_college_name() {
	return exa_college_name;
}
public void setExa_college_name(String exa_college_name) {
	this.exa_college_name = exa_college_name;
}
public String getExa_uni_name() {
	return exa_uni_name;
}
public void setExa_uni_name(String exa_uni_name) {
	this.exa_uni_name = exa_uni_name;
}
public String getExa_subject1() {
	return exa_subject1;
}
public void setExa_subject1(String exa_subject1) {
	this.exa_subject1 = exa_subject1;
}
public String getExa_subject2() {
	return exa_subject2;
}
public void setExa_subject2(String exa_subject2) {
	this.exa_subject2 = exa_subject2;
}
public String getExa_subject3() {
	return exa_subject3;
}
public void setExa_subject3(String exa_subject3) {
	this.exa_subject3 = exa_subject3;
}
public String getExa_subject4() {
	return exa_subject4;
}
public void setExa_subject4(String exa_subject4) {
	this.exa_subject4 = exa_subject4;
}

}
