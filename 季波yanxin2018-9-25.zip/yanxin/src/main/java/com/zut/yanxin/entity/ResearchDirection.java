package com.zut.yanxin.entity;

public class ResearchDirection {
private int res_id;
private String res_year;
private String res_name;
private String res_maj_name;
private String res_college_name;
private String res_uni_name;
private String res_way;
private int res_register_num;
private int res_enroll_num;
private int res_recommend_num;
public ResearchDirection(int res_id, String res_year, String res_name, String res_maj_name, String res_college_name,
		String res_uni_name, String res_way, int res_register_num, int res_enroll_num, int res_recommend_num) {
	super();
	this.res_id = res_id;
	this.res_year = res_year;
	this.res_name = res_name;
	this.res_maj_name = res_maj_name;
	this.res_college_name = res_college_name;
	this.res_uni_name = res_uni_name;
	this.res_way = res_way;
	this.res_register_num = res_register_num;
	this.res_enroll_num = res_enroll_num;
	this.res_recommend_num = res_recommend_num;
}
public int getRes_id() {
	return res_id;
}
public void setRes_id(int res_id) {
	this.res_id = res_id;
}
public String getRes_year() {
	return res_year;
}
public void setRes_year(String res_year) {
	this.res_year = res_year;
}
public String getRes_name() {
	return res_name;
}
public void setRes_name(String res_name) {
	this.res_name = res_name;
}
public String getRes_maj_name() {
	return res_maj_name;
}
public void setRes_maj_name(String res_maj_name) {
	this.res_maj_name = res_maj_name;
}
public String getRes_college_name() {
	return res_college_name;
}
public void setRes_college_name(String res_college_name) {
	this.res_college_name = res_college_name;
}
public String getRes_uni_name() {
	return res_uni_name;
}
public void setRes_uni_name(String res_uni_name) {
	this.res_uni_name = res_uni_name;
}
public String getRes_way() {
	return res_way;
}
public void setRes_way(String res_way) {
	this.res_way = res_way;
}
public int getRes_register_num() {
	return res_register_num;
}
public void setRes_register_num(int res_register_num) {
	this.res_register_num = res_register_num;
}
public int getRes_enroll_num() {
	return res_enroll_num;
}
public void setRes_enroll_num(int res_enroll_num) {
	this.res_enroll_num = res_enroll_num;
}
public int getRes_recommend_num() {
	return res_recommend_num;
}
public void setRes_recommend_num(int res_recommend_num) {
	this.res_recommend_num = res_recommend_num;
}

}
