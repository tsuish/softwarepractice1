package com.zut.yanxin.start;
import com.jfinal.core.JFinal;
public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFinal.start("src/main/webapp", 8080, "/", 5);
	}

}
