package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.MajorCatalogDao;
import com.zut.yanxin.entity.MajorCatalog;

public class MajorCatalogDaoImpl extends Model<MajorCatalogDaoImpl> implements MajorCatalogDao {

	private static final long serialVersionUID = 1L;
	public static final MajorCatalogDaoImpl dao = new MajorCatalogDaoImpl().dao();
	public static String sql = null;
	@Override
	public List<MajorCatalog> getInfo(String maj_uni_name) {
		sql = "select * from major_catalog where maj_uni_name=\""+maj_uni_name+"\"";
		List<MajorCatalog> list = new ArrayList<MajorCatalog>();
		List<MajorCatalogDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int maj_id = DaoImplList.get(i).getInt("maj_id");
			String maj_year = DaoImplList.get(i).getStr("maj_year");
			String maj_code = DaoImplList.get(i).getStr("maj_code");
			String maj_name = DaoImplList.get(i).getStr("maj_name");
			String maj_college_name = DaoImplList.get(i).getStr("maj_college_name");
			String maj_academic = DaoImplList.get(i).getStr("maj_academic");
			int maj_system = DaoImplList.get(i).getInt("maj_system");
			boolean maj_transdisciplinary = DaoImplList.get(i).getBoolean("maj_transdisciplinary");
			list.add(new MajorCatalog(maj_id,maj_year,maj_code,maj_name,maj_college_name,maj_uni_name,maj_academic,maj_system,maj_transdisciplinary));
		}
		return list;
	}

}
