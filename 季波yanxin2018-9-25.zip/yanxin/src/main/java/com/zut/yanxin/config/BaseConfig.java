package com.zut.yanxin.config;

import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.druid.DruidPlugin;
import com.jfinal.template.Engine;
import com.zut.yanxin.controller.RenderDataController;
import com.zut.yanxin.daoimpl.*;

public class BaseConfig extends JFinalConfig {

	@Override
	public void configConstant(Constants arg0) {
		// 加载数据库配置文件
		PropKit.use("db.properties");
		arg0.setDevMode(true);
		arg0.setEncoding("utf-8");
	}

	@Override
	public void configEngine(Engine arg0) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void configHandler(Handlers arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void configInterceptor(Interceptors arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void configPlugin(Plugins arg0) {
		// 配置数据库连接
		DruidPlugin dp = new DruidPlugin(PropKit.get("url"),PropKit.get("username"),PropKit.get("password"));
		dp.setDriverClass(PropKit.get("driver"));
		arg0.add(dp);
		//配置DaoImpl实现类中映射的表;
		ActiveRecordPlugin arp = new ActiveRecordPlugin(dp);
		arp.addMapping("exam_area", "exa_id",ExamAreaDaoImpl.class);
		arp.addMapping("major_catalog", "maj_id",MajorCatalogDaoImpl.class);
		arp.addMapping("recruit_page", "rec_id",RecruitPageDaoImpl.class);
		arp.addMapping("research_direction", "res_id",ResearchDirectionDaoImpl.class);
		arp.addMapping("score_level", "sco_id",ScoreLevelDaoImpl.class);
		arp.addMapping("university", "uni_id",UniversityDaoImpl.class);
		arg0.add(arp);
	}

	@Override
	public void configRoute(Routes arg0) {
		//配置controller控制器的访问路由
		arg0.add("/renderdata",RenderDataController.class);
	}

}
