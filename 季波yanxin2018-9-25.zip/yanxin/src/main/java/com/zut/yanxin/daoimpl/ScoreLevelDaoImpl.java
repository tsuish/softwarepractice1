package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.ScoreLevelDao;
import com.zut.yanxin.entity.ScoreLevel;

public class ScoreLevelDaoImpl extends Model<ScoreLevelDaoImpl> implements ScoreLevelDao {

	private static final long serialVersionUID = 1L;
	public static final ScoreLevelDaoImpl dao = new ScoreLevelDaoImpl().dao();
	public static String sql = null;
	@Override
	public List<ScoreLevel> getInfo(String sco_uni_name) {
		sql = "select * from score_level where sco_uni_name=\""+sco_uni_name+"\"";
		List<ScoreLevel> list = new ArrayList<ScoreLevel>();
		List<ScoreLevelDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int sco_id = DaoImplList.get(i).getInt("sco_id");
			String sco_year = DaoImplList.get(i).getStr("sco_year");
			String sco_maj_name = DaoImplList.get(i).getStr("sco_maj_name");
			String sco_college_name = DaoImplList.get(i).getStr("sco_college_name");
			int sco_country_line = DaoImplList.get(i).getInt("sco_country_line");
			int sco_self_line = DaoImplList.get(i).getInt("sco_self_line");
			int sco_reexamine_line = DaoImplList.get(i).getInt("sco_reexamine_line");
			int sco_subject1 = DaoImplList.get(i).getInt("sco_subject1");
			int sco_subject2 = DaoImplList.get(i).getInt("sco_subject2");
			int sco_subject3 = DaoImplList.get(i).getInt("sco_subject3");
			int sco_subject4 = DaoImplList.get(i).getInt("sco_subject4");
			list.add(new ScoreLevel(sco_id,sco_year,sco_maj_name,sco_college_name,sco_uni_name,sco_country_line,sco_self_line,sco_reexamine_line,sco_subject1,sco_subject2,sco_subject3,sco_subject4));
		}
		return list;
	}

}
