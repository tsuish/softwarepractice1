package com.zut.yanxin.entity;

public class MajorCatalog {
private int maj_id;
private String maj_year;
private String maj_code;
private String maj_name;
private String maj_college_name;
private String maj_uni_name;
private String maj_acdemic;
private int maj_system;
private boolean maj_transdisciplinary;
public MajorCatalog(int maj_id, String maj_year, String maj_code, String maj_name, String maj_college_name,
		String maj_uni_name, String maj_acdemic, int maj_system, boolean maj_transdisciplinary) {
	super();
	this.maj_id = maj_id;
	this.maj_year = maj_year;
	this.maj_code = maj_code;
	this.maj_name = maj_name;
	this.maj_college_name = maj_college_name;
	this.maj_uni_name = maj_uni_name;
	this.maj_acdemic = maj_acdemic;
	this.maj_system = maj_system;
	this.maj_transdisciplinary = maj_transdisciplinary;
}
public int getMaj_id() {
	return maj_id;
}
public void setMaj_id(int maj_id) {
	this.maj_id = maj_id;
}
public String getMaj_year() {
	return maj_year;
}
public void setMaj_year(String maj_year) {
	this.maj_year = maj_year;
}
public String getMaj_code() {
	return maj_code;
}
public void setMaj_code(String maj_code) {
	this.maj_code = maj_code;
}
public String getMaj_name() {
	return maj_name;
}
public void setMaj_name(String maj_name) {
	this.maj_name = maj_name;
}
public String getMaj_college_name() {
	return maj_college_name;
}
public void setMaj_college_name(String maj_college_name) {
	this.maj_college_name = maj_college_name;
}
public String getMaj_uni_name() {
	return maj_uni_name;
}
public void setMaj_uni_name(String maj_uni_name) {
	this.maj_uni_name = maj_uni_name;
}
public String getMaj_acdemic() {
	return maj_acdemic;
}
public void setMaj_acdemic(String maj_acdemic) {
	this.maj_acdemic = maj_acdemic;
}
public int getMaj_system() {
	return maj_system;
}
public void setMaj_system(int maj_system) {
	this.maj_system = maj_system;
}
public boolean isMaj_transdisciplinary() {
	return maj_transdisciplinary;
}
public void setMaj_transdisciplinary(boolean maj_transdisciplinary) {
	this.maj_transdisciplinary = maj_transdisciplinary;
}

}
